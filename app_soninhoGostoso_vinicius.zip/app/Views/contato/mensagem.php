<?= $this->extend('contato/modelo')?>
<?= $this->section('form')?>
<div class="align-center">
    <?= $msg; ?>
</div>
<?= $this->endSection() ?>